import arcade
from constants import SCREEN_WIDTH, SCREEN_HEIGHT
import sys

class GameOverView(arcade.View):
    """
    View to show when the game is over.
    """
    def __init__(self, winner_player_number):
        # Pass the main InternetGame window object
        super().__init__()
        self.winner = winner_player_number
        self.message = ""
        
        # Determine the message based on who this machine is (Host=P1, Client=P2)
        my_player_number = 1 if self.game.game_role == 'host' else 2
        
        if my_player_number == self.winner:
            self.message = "VICTORY! YOU SUNK ALL OPPONENT SHIPS!"
        else:
            self.message = "DEFEAT! ALL YOUR SHIPS WERE SUNK!"
        
        # Unschedule all active game updates/listeners from the main game loop
        arcade.unschedule(self.game._process_command)


    def on_draw(self):
        """ Draw the game over screen. """
        self.clear()
        
        arcade.draw_text(
            self.message,
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 + 50,
            arcade.color.GREEN if "VICTORY" in self.message else arcade.color.RED,
            font_size=50,
            anchor_x="center",
        )
        
        arcade.draw_text(
            "Press ESC to exit or R to return to connection screen.",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 - 50,
            arcade.color.WHITE,
            font_size=20,
            anchor_x="center",
        )

    def on_key_press(self, key, modifiers):
        """ Handle key presses to exit or restart. """
        if key == arcade.key.ESCAPE:
            # Cleanly exit the entire game
            sys.exit(0)
        elif key == arcade.key.R:
            # Go back to the connection screen to start a new game
            self.game.reset_game_state()
            self.game.show_connection_screen()



class WaitingView(arcade.View):
    """Simple screen to show while waiting for the opponent's network move."""
    def __init__(self, game_window):
        super().__init__()
        self.window = game_window
        arcade.set_background_color(arcade.color.LIGHT_GRAY)
        
    def on_draw(self):
        self.clear()
        arcade.draw_text(
            "Waiting for Opponent's Move...",
            self.window.width / 2,
            self.window.height / 2,
            arcade.color.BLACK,
            font_size=50,
            anchor_x="center",
        )

    # Disable all user input
    def on_key_press(self, key, modifiers):
        pass
        
    def on_mouse_press(self, x, y, button, modifiers):
        pass