import arcade
import threading
import socket
import json
import sys
import time

# NOTE: You must ensure these imports point to your correctly defined files
from setup import SetupView 
from battle import BattleView
from connect import ConnectView 
from internet_other_screens import GameOverView, WaitingView 
from constants import SCREEN_WIDTH, SCREEN_HEIGHT, player1_board, player2_board, SQUARE_SIZE, blank_board 

# ----------------- Utility for showing local IP ------------------

def get_local_ip():
    """Gets the non-loopback local IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)) 
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return socket.gethostbyname(socket.gethostname())


# ----------------- InternetGame Class (Main Window) -----------------

class InternetGame(arcade.Window):
    """Main Internet Game class controlling the flow between setup and battle views."""
    
    def __init__(self):
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, "Battleship Internet")
        
        self.player1_setup_data = None
        self.player2_setup_data = None
        
        self.player1_board = blank_board.copy()
        self.player2_board = blank_board.copy()

        # Track current player for setup and battle (P1 is always the starting player)
        self.current_player = 1 
        
        # Networking attributes
        self.port = 5555
        self.host_ip = None 
        self.server_socket = None
        self.client_socket = None 
        self.game_role = None # 'host' or 'client'
        
        self.show_connection_screen()

    # =========================================================================
    # 1. NETWORKING UTILITIES (Send/Receive/Listen)
    # =========================================================================

    def send_data(self, data):
        """Helper function to JSON serialize and send data over the client socket."""
        if not self.client_socket:
            print("Error: Client socket not available for sending.")
            return

        try:
            message = json.dumps(data).encode('utf-8')
            length_prefix = f"{len(message):<10}"
            self.client_socket.sendall(length_prefix.encode('utf-8') + message)
        except Exception as e:
            print(f"Error sending data: {e}")
            self._handle_disconnect_scheduled()

    def receive_data(self):
        """Helper function to receive a full message and JSON deserialize it."""
        if not self.client_socket:
            return None
            
        try:
            length_prefix = self.client_socket.recv(10).decode('utf-8').strip()
            if not length_prefix:
                return None
                
            message_length = int(length_prefix)
            
            full_message = b''
            bytes_received = 0
            while bytes_received < message_length:
                chunk = self.client_socket.recv(min(message_length - bytes_received, 2048))
                if not chunk:
                    break
                full_message += chunk
                bytes_received += len(chunk)
            
            if bytes_received < message_length:
                 print("Warning: Did not receive full message.")
                 return None

            return json.loads(full_message.decode('utf-8'))

        except ConnectionResetError:
            print("Connection forcibly closed by the remote host.")
            # FIX: Schedule the disconnection handling on the main thread
            arcade.schedule(lambda dt: self._handle_disconnect_scheduled(), 0)
            return None
        except Exception:
            # Handle other connection errors (e.g., socket timeout, unexpected close)
            if self.client_socket: # Only schedule if connection was active
                arcade.schedule(lambda dt: self._handle_disconnect_scheduled(), 0)
            return None

    def _listen_for_data(self):
        """Runs in a background thread to continuously receive messages."""
        while self.client_socket:
            data = self.receive_data()
            if data is None:
                break
                
            # Messages received are processed on the main thread
            arcade.schedule(lambda dt: self._process_command(data), 0)
            
        print("Network listener thread stopped.")


    def _process_command(self, data):
        """Processes a received command on the main thread."""
        command = data.get("command")
        
        if command == "ATTACK":
            key = data.get("target")
            self._handle_incoming_attack(key)
        
        elif command == "ATTACK_RESPONSE":
            result = data.get("result") # 0=Miss, 1=Hit, 2=Sunk
            key = data.get("target")
            effected_ships = data.get("effected_ships") 
            check_end = data.get("check_end", False)
            self._handle_attack_response(key, result, effected_ships, check_end)

        elif command == "SETUP_DATA":
            player_number = data.get("player")
            ship_data = data.get("ship_data")
            board_data = data.get("board_data")
            
            if player_number == 1:
                self.player1_setup_data = ship_data
                self.player1_board = board_data
            else:
                self.player2_setup_data = ship_data
                self.player2_board = board_data
                
            print(f"Received setup data for Player {player_number}.")
            
            if self.player1_setup_data and self.player2_setup_data:
                self.start_game()
        else:
            print(f"Unknown command received: {command}")


    # =========================================================================
    # 2. CONNECTION HANDLERS (Host/Join)
    # =========================================================================

    def show_connection_screen(self):
        connect_view = ConnectView()
        self.show_view(connect_view)

    def host_connect(self, host_ip):
        self.game_role = 'host'
        self.host_ip = host_ip
        self.start_server()

    def join_connect(self, host_ip):
        self.game_role = 'client'
        port = 5555 
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        try:
            print(f"Attempting to connect to {host_ip}:{port}...")
            client_socket.connect((host_ip, port))
            
            print("Successfully connected to host!")
            self.client_socket = client_socket
            
            threading.Thread(target=self._listen_for_data, daemon=True).start()
            
            # Client starts setup (Player 2)
            self.show_player_setup(player_number=2) 
            
        except socket.error as e:
            print(f"Connection failed: Could not reach host at {host_ip}:{port}")
            print(f"Error details: {e}")
            client_socket.close()
    
    def start_server(self):
        """Starts a thread to wait for a connection."""
        threading.Thread(target=self.wait_for_connection, daemon=True).start()
    
    def wait_for_connection(self):
        """Runs in a background thread to listen for the client."""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            self.server_socket.bind((self.host_ip, self.port))
            self.server_socket.listen(1)
            print(f"Server listening on {self.host_ip}:{self.port}")

            self.client_socket, address = self.server_socket.accept() 
            
            print(f"Connection established with client at {address}")
            
            threading.Thread(target=self._listen_for_data, daemon=True).start()
            
            arcade.schedule(self._start_host_setup, 0)
            
        except Exception as e:
            print(f"Server error: {e}")
        finally:
            if self.server_socket:
                # The server socket is closed after client connection is established 
                # or an error occurs.
                pass 

    def _start_host_setup(self, dt):
        """Helper to switch view on the main thread after a successful connection."""
        self.show_player_setup(player_number=1) 
        arcade.unschedule(self._start_host_setup) 

    def _handle_disconnect_scheduled(self):
        """Called by the scheduler to ensure thread safety for GUI updates."""
        self._handle_disconnect()
        
    def _handle_disconnect(self):
        """Handles closing connections and informing the user about the disconnect."""
        
        # Cleanup network resources first (OK on any thread, but scheduled for safety)
        if self.client_socket:
            self.client_socket.close()
            self.client_socket = None

        if self.server_socket:
            # Server socket is usually closed in wait_for_connection, but clean up just in case
            # self.server_socket.close() 
            # self.server_socket = None
            pass 
            
        print("Disconnected. Returning to connection screen.")
        # This view change now happens safely on the main thread
        self.show_connection_screen()
        
    def reset_game_state(self):
        """Resets all necessary state variables to allow for a new game."""
        self.player1_setup_data = None
        self.player2_setup_data = None
        self.player1_board = blank_board.copy()
        self.player2_board = blank_board.copy()
        self.current_player = 1 
        self.game_role = None


    # =========================================================================
    # 3. GAME FLOW AND VIEW SWITCHING (Modified)
    # =========================================================================
    
    def show_waiting_screen(self):
        """Show a screen indicating the game is waiting for the opponent's move."""
        print("Switching to Waiting View. Opponent's turn.")
        waiting_view = WaitingView(self)
        self.show_view(waiting_view)
        
    def show_player_setup(self, player_number):
        """Show the SetupView for the given player."""
        board = self.player1_board if player_number == 1 else self.player2_board
        setup_view = SetupView(player_number, self, board)
        self.show_view(setup_view)

    def show_player_battle(self, player_number):
        """
        Show the BattleView for the given player.
        The BattleView's __init__ will determine if it should be active or redirect to WaitingView.
        """
        setup_data = self.player1_setup_data if player_number == 1 else self.player2_setup_data
        your_board = self.player1_board if player_number == 1 else self.player2_board
        opponents_board = self.player2_board if player_number == 1 else self.player1_board

        battle_view = BattleView(
            player_number, 
            self, 
            setup_data, 
            your_board, 
            opponents_board, 
        )
        self.show_view(battle_view)

    def show_game_over_screen(self, winner_player_number):
        """Show the game over view."""
        game_over_view = GameOverView(winner_player_number)
        self.show_view(game_over_view)


    def on_setup_finished(self, player_number, ship_data, board):
        """Called by SetupView when a player finishes placing ships."""
        
        # 1. Save your own data locally
        if player_number == 1:
            self.player1_setup_data = ship_data
            self.player1_board = board
        else:
            self.player2_setup_data = ship_data
            self.player2_board = board
            
        # 2. Send your ship data to the opponent
        setup_message = {
            "command": "SETUP_DATA",
            "player": player_number,
            "ship_data": ship_data,
            "board_data": board
        }
        self.send_data(setup_message)
        
        print(f"Player {player_number} setup complete. Waiting for opponent's data...")
        # Stays on SetupView until opponent's data is received and start_game() is called.


    def start_game(self):
        """Switch to battle view after both players finish setup."""
        print("Starting the battle!")
        self.current_player = 1  # Always start battle with Player 1 (Host)
        
        my_player_number = 1 if self.game_role == 'host' else 2
        
        # The BattleView init will automatically redirect to WaitingView if it's not my turn
        self.show_player_battle(my_player_number)


    # =========================================================================
    # 4. BATTLE LOGIC (Networking Integrated)
    # =========================================================================

    def request_attack(self, player_number, key):
        """
        (Attacking Machine) Sends an attack request to the opponent's machine.
        Called by BattleView.on_mouse_press().
        """
        if not self.client_socket:
             print("Cannot attack: No connection.")
             return

        attack_data = {
            "command": "ATTACK",
            "target": key, 
            "attacker": player_number
        }
        
        self.send_data(attack_data)
        
        print(f"Attack request sent to opponent at {key}. Waiting for response...")


    def _handle_incoming_attack(self, key):
        """
        (Defending Machine) Called when the opponent fires a shot.
        Calculates the result, updates its own board, sends a response, and switches the turn.
        """
        # Determine your player number (The host is P1, the client is P2)
        your_player_number = 1 if self.game_role == 'host' else 2
        
        # This is YOUR board and YOUR ship data
        board = self.player1_board if your_player_number == 1 else self.player2_board
        ship_data = self.player1_setup_data if your_player_number == 1 else self.player2_setup_data
        effected_ships = []
        result = 0 # 0=Miss, 1=Hit, 2=Sunk
        
        # --- Attack logic ---
        if key in board and board.get(key) == 1:
            board[key] = 2 
            result = 1
            for ship in ship_data:
                 for part_index, part in enumerate(ship):
                    (x, y, angle), hit = part
                    
                    # Convert coordinates to grid key to match 'key'
                    col = int((x - (SCREEN_WIDTH - SQUARE_SIZE * 10) / 2) // SQUARE_SIZE)
                    row = int((y - (SCREEN_HEIGHT - SQUARE_SIZE * 10) / 2) // SQUARE_SIZE)
                    part_key = chr(ord('A') + row) + str(col + 1)

                    if part_key == key:
                        ship[part_index][1] = 1 # mark hit True in ship_data
                        if all(p[1] == 1 for p in ship):
                            # Sunk! Update board keys to mark as destroyed (4)
                            for p in ship:
                                (px, py, _) , _ = p
                                c = int((px - (SCREEN_WIDTH - SQUARE_SIZE * 10) / 2) // SQUARE_SIZE)
                                r = int((py - (SCREEN_HEIGHT - SQUARE_SIZE * 10) / 2) // SQUARE_SIZE)
                                destroyed_key = chr(ord('A') + r) + str(c + 1)
                                if destroyed_key in board:
                                    board[destroyed_key] = 4
                                    effected_ships.append(destroyed_key)
                            result = 2 # Sunk result
                        break
        else:
            if key in board and board.get(key) == 0:
                 board[key] = 3
        # --------------------

        check_end = self.check_if_game_end(your_player_number)

        # 1. Send the result back to the attacking player
        response = {
            "command": "ATTACK_RESPONSE",
            "target": key,
            "result": result, 
            "effected_ships": effected_ships,
            "check_end": check_end 
        }
        self.send_data(response)
        
        # 2. Update the local board data
        if your_player_number == 1:
            self.player1_board = board
            self.player1_setup_data = ship_data
        else:
            self.player2_board = board
            self.player2_setup_data = ship_data

        # 3. Handle Game Over (If this machine is the one that lost)
        if check_end:
            winner_number = 1 if your_player_number == 2 else 2
            print(f"Game Over! Player {winner_number} won.")
            self.show_game_over_screen(winner_number)
            return

        # 4. CRITICAL: Turn Switch (It's now the defender's turn/Attacker)
        self.current_player = your_player_number
        
        # 5. Force a view refresh to start the turn on this machine
        self.show_player_battle(your_player_number) 


    def _handle_attack_response(self, key, result, effected_ships = None, check_end = None):
        """
        (Attacking Machine) Called when the opponent responds to your attack.
        Updates your view of the opponent's board and switches the turn.
        """
        your_player_number = 1 if self.game_role == 'host' else 2
        
        # Get the opponent's board (your *tracking* board)
        opponents_board = self.player2_board if your_player_number == 1 else self.player1_board
        
        # --- Update the tracking board ---
        if result == 0: # Miss
            opponents_board[key] = 3 
            print(f"Attack on {key}: MISS")
        elif result == 1: # Hit
            opponents_board[key] = 2
            print(f"Attack on {key}: HIT")
        elif result == 2: # Sunk
            opponents_board[key] = 4
            print(f"Attack on {key}: SHIP SUNK!")
            if effected_ships:
                 for part in effected_ships:
                     opponents_board[part] = 4
        # -----------------------------------
            
        # 1. Update the board state locally
        if your_player_number == 1:
            self.player2_board = opponents_board
        else:
            self.player1_board = opponents_board
            
        # 2. Check for Game End (If you are the one who won)
        if check_end:
            self.show_game_over_screen(your_player_number)
            return 
            
        # 3. CRITICAL: Turn Switch 
        # The turn switches to the OPPONENT (the one who just responded/defended)
        self.current_player = 1 if your_player_number == 2 else 2

        # 4. Now switch the view back to the current player's battle view (which is now passive)
        self.show_player_battle(your_player_number)


    def check_if_game_end(self, player_number):
        """Checks if the player (player_number) still has any ships left."""
        board = self.player1_board if player_number == 1 else self.player2_board
        for key, value in board.items():
            if value == 1: # A ship piece still exists
                return False
        return True # All ships destroyed