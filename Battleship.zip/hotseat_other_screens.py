import arcade
from constants import SCREEN_WIDTH, SCREEN_HEIGHT

class GameOverView(arcade.View):
    """
    View to show when the game is over.
    """
    def __init__(self, winner_player_number):
        # Pass the main InternetGame window object
        super().__init__()
        self.winner = winner_player_number
        self.message = f"VICTORY! PLAYER {winner_player_number} HAS SUNK ALL OPPONENT SHIPS!"


    def on_draw(self):
        """ Draw the game over screen. """
        self.clear()
        
        arcade.draw_text(
            self.message,
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 + 50,
            arcade.color.GREEN if "VICTORY" in self.message else arcade.color.RED,
            font_size=50,
            anchor_x="center",
        )
        
        arcade.draw_text(
            "Press ESC to exit or R to return to main menu screen.",
            SCREEN_WIDTH / 2,
            SCREEN_HEIGHT / 2 - 50,
            arcade.color.WHITE,
            font_size=20,
            anchor_x="center",
        )

    def on_key_press(self, key, modifiers):
        """ Handle key presses to exit or restart. """
        if key == arcade.key.ESCAPE:
            # Cleanly exit the entire game
            arcade.exit()
        elif key == arcade.key.R:
            # Go back to the connection screen to start a new game
            self.game.reset_game_state()
            self.game.show_connection_screen()


class WaitingView(arcade.View):
    """View to enforce hotseat passing, requiring a key press to continue."""
    def __init__(self, game_window, next_player_number):
        super().__init__()
        self.window = game_window
        self.next_player_number = next_player_number

    def on_show_view(self):
        arcade.set_background_color(arcade.color.BLACK)

    def on_draw(self):
        self.clear()
        message = f"Turn Over. Player {self.next_player_number}'s turn is next."
        prompt = f"Player {self.next_player_number} press [Space] when ready."

        arcade.draw_text(
            message,
            self.window.width / 2,
            self.window.height / 2 + 50,
            arcade.color.WHITE,
            36,
            anchor_x="center"
        )
        
        arcade.draw_text(
            prompt,
            self.window.width / 2,
            self.window.height / 2 - 50,
            arcade.color.YELLOW,
            24,
            anchor_x="center"
        )

    def on_key_press(self, key, modifiers):
        if key == arcade.key.SPACE:
            self.window.show_player_battle(self.next_player_number)